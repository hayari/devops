Role Name
=========

Manages cron

Example Playbook
----------------


    - hosts: servers
      roles:
         - orahost-cron

