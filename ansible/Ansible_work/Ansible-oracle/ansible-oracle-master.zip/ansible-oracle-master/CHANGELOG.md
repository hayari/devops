<b> Changelog (bigger changes) </b>


2015-01-07
- Added support for 11.2.0.3

2014-11-20
- Added support for Flex Clusters

2014-11-06
- Added support for running multiple databases from each ORACLE_HOME

2014-10-19
- Added support for udev device name persistence

2014-10-10
- Added 'oracle_gi_nic_pub|priv' and removed hardcoded nic's in grid-install template. Now possible to define which interface does what
- Added support for installation from remote location (e.g nfs share)
- Changed parameter name oracle_asm_crs_diskgroup to oracle_asm_init_dg

2014-10-09
- Added support for Container Databases


2014-10-07
- Added support for GI role separation


2014-09-28
- New role: oradb-delete, and parameters to support that role

2014-09-25
- Added support for 11.2.0.4

